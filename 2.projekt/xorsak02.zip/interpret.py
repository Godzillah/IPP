from parseArgsAndXml import parseArgs
from parseArgsAndXml import xmlParse

xmlParse(parseArgs())